import React, { useEffect } from 'react'
import Header from './components/Header/Header'
import Hero from './components/Hero/Hero'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import LoginPage from './components/Auth/Login';
import SignupPage from './components/Auth/Signup';
import Cookies from 'js-cookie';
import Dashboard from './pages/Dashboard';
import UserProfile from './pages/UserProfile';

const App = () => {
  useEffect(() => {
    // Check for the token cookie when the component mounts
    const token = Cookies.get('token');
    if (token) {
      console.log('Token found:', token);
      // You can perform any action, such as redirecting the user or setting state
    } else {
      console.log('No token found');
    }
  },[]);
  return (
    <Router>
      <Routes>
        <Route path='/' element={<LandingPage />} />
        <Route path='/login' element={<LoginPage />} />
        <Route path='/signup' element={<SignupPage />} />
        <Route path='/dashboard' element={<Dashboard />} />
        <Route path='/userprofile' element={<UserProfile />} />
      </Routes>
    </Router>
  )
}

export default App
import React, { useEffect, useState } from 'react';
import DashboardHeader from '../components/Header/DashboardHeader';
import OfferHeader from '../components/Header/OfferHeader';
import axios from 'axios';
import { FaUserCog } from 'react-icons/fa';
import { BiLoader } from 'react-icons/bi';
import { AiOutlineMail, AiOutlinePhone, AiOutlineLock } from 'react-icons/ai';
// import ChangePasswordModal from '../components/ChangePasswordModal';
import toast, { Toaster } from 'react-hot-toast';
import ChangePasswordModal from '../components/changePasswordModal';

const UserProfile = () => {
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [newAddress, setNewAddress] = useState('');
    const [isEditingAddress, setIsEditingAddress] = useState(false); // State for controlling address edit mode

    const getProfile = async () => {
        try {
            const response = await axios.get('http://localhost:8000/user/getUserProfile', {
                withCredentials: true,
            });
            setProfile(response.data);
            setNewAddress(response.data.address || ''); // Initialize address state
        } catch (error) {
            setError('Failed to load profile. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        getProfile();
    }, []);

    const handleChangePassword = () => {
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    const handleAddressUpdate = async () => {
        try {
            await axios.post('http://localhost:8000/user/updateAddress', { address: newAddress, email: profile.email }, { withCredentials: true });
            setProfile((prev) => ({ ...prev, address: newAddress }));
            setError(null); // Reset any previous error
            toast.success('Address updated successfully!');
            setIsEditingAddress(false); // Exit edit mode
        } catch (error) {
            setError('Failed to update address. Please try again.');
            toast.error('Failed to update address. Please try again.');
        }
    };

    return (
        <>
            <Toaster position="top-center" reverseOrder={false} />
            <OfferHeader />
            <DashboardHeader />
            <div className='flex justify-center mt-0 items-center'>
                <div className='w-[500px] bg-white rounded-lg shadow-lg p-6 flex flex-col items-center'>
                    {loading ? (
                        <div className='flex items-center justify-center'>
                            <BiLoader className='animate-spin text-blue-500 text-4xl' />
                        </div>
                    ) : error ? (
                        <h1 className='text-red-500'>{error}</h1>
                    ) : (
                        <>
                            <img
                                src={profile?.profilePicture || 'https://static.vecteezy.com/system/resources/thumbnails/000/439/863/small/Basic_Ui__28186_29.jpg'}
                                alt="Profile"
                                className='w-32 h-32 rounded-full border-2 border-blue-500 mb-4'
                            />
                            <h1 className='font-semibold text-2xl text-blue-600 mb-4 flex items-center'>
                                <FaUserCog className='mr-2' />
                                {profile?.name.toUpperCase()}
                            </h1>

                            <div className='w-full mb-4'>
                                <label className='font-medium text-lg flex items-center'>
                                    <AiOutlineMail className='text-blue-500 mr-2' />
                                    Email:
                                </label>
                                <div className='border rounded-md p-2 bg-gray-100'>
                                    <span>{profile?.email}</span>
                                </div>
                            </div>

                            <div className='w-full mb-4'>
                                <label className='font-medium text-lg flex items-center'>
                                    <AiOutlinePhone className='text-blue-500 mr-2' />
                                    Contact:
                                </label>
                                <div className='border rounded-md p-2 bg-gray-100'>
                                    <span>{profile?.contact}</span>
                                </div>
                            </div>

                            <div className='w-full mb-4'>
                                <label className='font-medium text-lg'>Address:</label>
                                <div className='border rounded-md p-2 bg-gray-100 mb-2'>
                                    <span>{profile?.address || 'No address provided'}</span>
                                </div>
                                
                                {isEditingAddress ? (
                                    <div className=''>
                                        <input
                                            type='text'
                                            value={newAddress}
                                            onChange={(e) => setNewAddress(e.target.value)}
                                            placeholder='Enter new address'
                                            className='border rounded-md p-2 w-full mb-2'
                                        />
                                        <button
                                            onClick={handleAddressUpdate}
                                            className='bg-blue-600 text-white px-4 py-2 rounded-md'
                                        >
                                            Update Address
                                        </button>
                                        <button
                                            onClick={() => setIsEditingAddress(false)}
                                            className='mt-2 text-red-500 ml-4'
                                        >
                                            Cancel
                                        </button>
                                    </div>
                                ) : (
                                    <button
                                        onClick={() => setIsEditingAddress(true)}
                                        className='mt-2 bg-blue-600 text-white px-4 py-2 rounded-md'
                                    >
                                        Edit Address
                                    </button>
                                )}
                            </div>

                            <div className='w-full mb-4'>
                                <label className='font-medium text-lg'>Bookings:</label>
                                <div className='border rounded-md p-2 bg-gray-100'>
                                    <span>{profile?.bookings.length === 0 ? 'No bookings' : profile.bookings.length}</span>
                                </div>
                            </div>

                            <button
                                onClick={handleChangePassword}
                                className='flex items-center mt-4 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-blue-700 transition-colors'
                            >
                                <AiOutlineLock className='mr-2' />
                                Change Password
                            </button>
                        </>
                    )}
                </div>
            </div>

            <ChangePasswordModal isOpen={isModalOpen} onClose={closeModal} email={profile?.email} />
        </>
    );
};

export default UserProfile;

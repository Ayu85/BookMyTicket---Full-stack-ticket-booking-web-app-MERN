import React, { useEffect } from 'react';
import Header from '../components/Header/Header'
import Hero from '../components/Hero/Hero'
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
const LandingPage = () => {
    const navigate = useNavigate(); // Create navigate function

    useEffect(() => {
        // Check if the user is already logged in
        if (Cookies.get('token')) {
            navigate('/dashboard'); // Redirect to the dashboard if logged in
        }
    }, [navigate]);

    return (
        <>
            <Header />
            <Hero />
        </>
    )
}

export default LandingPage
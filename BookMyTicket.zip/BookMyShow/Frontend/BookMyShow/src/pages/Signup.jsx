import React from 'react'
import SignupPage from '../components/Auth/Signup'

const Signup = () => {
  return (
    <div>
        <SignupPage/>
    </div>
  )
}

export default Signup
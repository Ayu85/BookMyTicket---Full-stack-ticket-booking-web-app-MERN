import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import OfferHeader from '../components/Header/OfferHeader';
import DashboardHeader from '../components/Header/DashboardHeader';
import MovieList from '../components/Movie/MovieList';

const Dashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if the user is logged in by verifying the token
    if (!Cookies.get('token')) {
      navigate('/'); // Redirect to the root route if no token is found
    }
  }, [navigate]);

  return (
    <div>
      <OfferHeader />
      <DashboardHeader />
      <MovieList/>
      {/* Your dashboard content */}
    </div>
  );
};

export default Dashboard;

import { createSlice } from "@reduxjs/toolkit";

const movieSlice = createSlice({
    name: "movies",
    initialState: {
        value: null
    },
    reducers: {
        addMovies: (state, action) => {
            state.value=action.payload
        }
    }
})
export const {addMovies}=movieSlice.actions
export default movieSlice.reducer;
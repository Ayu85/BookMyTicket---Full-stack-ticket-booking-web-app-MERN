import React from 'react'

const Hero = () => {
    return (
        <div style={{ backgroundImage: `url(https://images7.alphacoders.com/134/1341524.png)` }}
            className='w-screen selection:bg-zinc-500 h-screen bg-cover bg-bottom '>
            <div className='w-full h-full bg-black bg-opacity-70 flex flex-col gap-3 items-center pt-72 text-white'>
                <h1 className='inter-bold text-5xl'>Camp More, Worry Less – Book Your Getaway!</h1>
                <h2 className='inter-medium text-xl text-slate-300'>Leave the stress behind and immerse yourself in the beauty of the outdoors</h2>
                <button className='border px-6  py-2 mt-5
                inter active:scale-110 hover:bg-white hover:bg-opacity-30 transition-all'>Browse Camps</button>

            </div>
        </div>
    )
}

export default Hero
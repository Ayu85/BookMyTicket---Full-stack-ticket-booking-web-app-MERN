import React, { useContext, useEffect, useState } from 'react';
import { AiOutlineMail, AiOutlineLock } from 'react-icons/ai';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios'
import toast, { Toaster } from 'react-hot-toast';
import { AuthContext } from '../AuthContext';
import Cookies from 'js-cookie';

const LoginPage = () => {
    const [mail, setMail] = useState('')
    const [password, setPass] = useState('')
    const { login } = useContext(AuthContext);
    const navigate = useNavigate()
    useEffect(() => {
        // Check if the user is already logged in
        if (Cookies.get('token')) {
          navigate('/dashboard'); // Redirect to the dashboard if logged in
        }
      }, [navigate]);
    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            const response = await axios.post('http://localhost:8000/user/loginUser', { email: mail, password }, { withCredentials: true })
            console.log(response);
            toast.success('Logged in successfully!')
            login()
            navigate('/dashboard')

        } catch (error) {
            console.log(error);
            toast.error(error?.response?.data?.msg || 'Server Error!')

        }
    }
    return (
        <div style={{ backgroundImage: `url(https://images7.alphacoders.com/134/1341524.png)` }}
            className=" bg-cover flex items-center inter justify-center h-screen bg-gray-900 text-white">
            <Toaster
                position="top-center"
                reverseOrder={false}
                gutter={8}
                containerClassName=""
                containerStyle={{}}
                toastOptions={{
                    // Define default options
                    className: '',
                    duration: 5000,
                    style: {
                        background: '#363636',
                        color: '#fff',
                    },

                    // Default options for specific types
                    success: {
                        duration: 3000,
                        theme: {
                            primary: 'green',
                            secondary: 'black',
                        },
                    },
                }}
            />
            <div className='bg-black w-full h-full bg-opacity-50 flex items-center justify-center' >
                <div className="bg-gray-800 p-8 rounded-lg shadow-md w-96">
                    <h2 className="text-2xl  mb-6 text-center inter-semibold">Login</h2>
                    <form >
                        <div className="mb-4">
                            <label className="block mb-1" htmlFor="email">Email</label>
                            <div className="flex items-center border border-gray-600 rounded-md">
                                <span className="p-2 text-gray-400">
                                    <AiOutlineMail />
                                </span>
                                <input
                                    type="email"
                                    id="email"
                                    className="bg-gray-700 text-white p-2 rounded-md outline-none flex-1"
                                    placeholder="Enter your email"
                                    required
                                    onChange={(e) => setMail(e.target.value)}
                                />
                            </div>
                        </div>
                        <div className="mb-6">
                            <label className="block mb-1" htmlFor="password">Password</label>
                            <div className="flex items-center border border-gray-600 rounded-md">
                                <span className="p-2 text-gray-400">
                                    <AiOutlineLock />
                                </span>
                                <input
                                    type="password"
                                    id="password"
                                    className="bg-gray-700 text-white p-2 rounded-md outline-none flex-1"
                                    placeholder="Enter your password"
                                    required
                                    onChange={(e) => setPass(e.target.value)}

                                />
                            </div>
                        </div>
                        <button onClick={(e) => handleSubmit(e)} type='submit' className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 rounded-md">
                            Login
                        </button>
                    </form>
                    <p className="mt-4 text-center">
                        Don’t have an account? <Link to="/signup" className="text-blue-400">Sign up</Link>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;

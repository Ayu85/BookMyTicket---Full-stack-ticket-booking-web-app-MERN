// SignupPage.js
import React, { useState } from 'react';
import { AiOutlineUser, AiOutlineMail, AiOutlineLock,AiOutlinePhone } from 'react-icons/ai';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const SignupPage = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [contact, setContact] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const response = await axios.post('http://localhost:8000/user/signUpUser', {
                name,
                email,
                password,
                contact,
            });
            if (response.data.success) {
                // Redirect to login or another page after successful signup
                navigate('/login');
            } else {
                setError(response.data.msg);
            }
        } catch (error) {
            setError('An error occurred during signup. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ backgroundImage: `url(https://images7.alphacoders.com/134/1341524.png)` }}
            className="flex bg-cover inter items-center justify-center h-screen text-white">
            <div className='bg-black w-full h-full bg-opacity-50 flex items-center justify-center'>
                <div className="bg-gray-800 p-8 rounded-lg shadow-md w-96">
                    <h2 className="text-2xl mb-6 text-center inter-semibold">Sign Up</h2>
                    {error && <p className="text-red-500 text-center mb-4">{error}</p>}
                    <form onSubmit={handleSubmit}>
                        <div className="mb-4">
                            <label className="block mb-1" htmlFor="name">Name</label>
                            <div className="flex items-center border border-gray-600 rounded-md">
                                <span className="p-2 text-gray-400">
                                    <AiOutlineUser />
                                </span>
                                <input
                                    type="text"
                                    id="name"
                                    className="bg-gray-700 text-white p-2 rounded-md outline-none flex-1"
                                    placeholder="Enter your name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    required
                                />
                            </div>
                        </div>
                        <div className="mb-4">
                            <label className="block mb-1" htmlFor="email">Email</label>
                            <div className="flex items-center border border-gray-600 rounded-md">
                                <span className="p-2 text-gray-400">
                                    <AiOutlineMail />
                                </span>
                                <input
                                    type="email"
                                    id="email"
                                    className="bg-gray-700 text-white p-2 rounded-md outline-none flex-1"
                                    placeholder="Enter your email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                        </div>
                        <div className="mb-6">
                            <label className="block mb-1" htmlFor="password">Password</label>
                            <div className="flex items-center border border-gray-600 rounded-md">
                                <span className="p-2 text-gray-400">
                                    <AiOutlineLock />
                                </span>
                                <input
                                    type="password"
                                    id="password"
                                    className="bg-gray-700 text-white p-2 rounded-md outline-none flex-1"
                                    placeholder="Enter your password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                            </div>
                        </div>
                        <div className="mb-4">
                            <label className="block mb-1" htmlFor="contact">Contact</label>
                            <div className="flex items-center border border-gray-600 rounded-md">
                                <span className="p-2 text-gray-400">
                                    <AiOutlinePhone />
                                </span>
                                <input
                                    type="text"
                                    id="contact"
                                    className="bg-gray-700 text-white p-2 rounded-md outline-none flex-1"
                                    placeholder="Enter your contact number"
                                    value={contact}
                                    onChange={(e) => setContact(e.target.value)}
                                    required
                                />
                            </div>
                        </div>
                        <button 
                            type="submit" 
                            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 rounded-md"
                            disabled={loading}
                        >
                            {loading ? 'Signing Up...' : 'Sign Up'}
                        </button>
                    </form>
                    <p className="mt-4 text-center">
                        Already have an account? <Link to="/login" className="text-blue-400">Login</Link>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default SignupPage;

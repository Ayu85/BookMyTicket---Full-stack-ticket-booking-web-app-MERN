// BookingModal.js
import React, { useState } from 'react';
import { FaTimes } from 'react-icons/fa';
import axios from 'axios';
import Cookies from 'js-cookie';

const BookingModal = ({ movie, isOpen, onClose }) => {
    const [seats, setSeats] = useState(1);
    const [selectedCinema, setSelectedCinema] = useState(movie?.show_timings[0].cinema);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    if (!isOpen) return null;

    const handleSeatsChange = (e) => {
        setSeats(e.target.value);
    };

    const handleCinemaChange = (e) => {
        setSelectedCinema(e.target.value);
    };

    const handleBooking = async () => {
        setLoading(true);
        setError(null);
        
        const bookingData = {
            user: Cookies.get('user_id'), // Assuming you have a user_id stored in cookies
            moviename: movie.title,
            totalAmount: seats * 500, // Assuming a fixed price of 10 per seat for example
            totalSeats: seats,
            theatreName: selectedCinema,
        };

        try {
            const response = await axios.post('http://localhost:8000/movie/bookticket', bookingData, {
                withCredentials: true, // Ensure cookies are sent with the request
            });
            console.log('Booking successful:', response.data);
            onClose(); // Close the modal after booking
        } catch (error) {
            console.error('Error booking tickets:', error);
            setError('Failed to book tickets. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-70 z-50">
            <div className="bg-white p-5 rounded-lg shadow-lg relative w-11/12 md:w-1/3">
                <FaTimes className="absolute top-2 right-2 text-gray-700 cursor-pointer" onClick={onClose} />
                <h2 className="text-2xl font-bold text-gray-800 mb-2 flex items-center">
                    🎬 {movie.title} 🎟️
                </h2>
                <img src={movie.poster_path} alt={movie.title} className="w-full h-48 object-cover rounded mb-4 border-2 border-gray-300" />
                <p className="text-gray-800">Rating: ⭐ {movie.rating} ({movie.total_votes} votes)</p>
                <h4 className="mt-4 text-lg font-semibold text-gray-800">Show Timings:</h4>
                <ul className="text-gray-800">
                    {movie?.show_timings.map((show, index) => (
                        <li key={index} className="flex justify-between">
                            <span>🎥 {show.cinema}</span>
                            <span>🕒 {show.timing} ({show.location})</span>
                        </li>
                    ))}
                </ul>

                {/* Dropdown for selecting number of seats */}
                <div className="mt-4">
                    <label className="block text-gray-800 mb-2" htmlFor="seats">
                        Select Number of Seats:
                    </label>
                    <select
                        id="seats"
                        value={seats}
                        onChange={handleSeatsChange}
                        className="border border-gray-300 rounded-md p-2 w-full"
                    >
                        {[...Array(10).keys()].map(i => (
                            <option key={i} value={i + 1}>{i + 1}</option>
                        ))}
                    </select>
                </div>

                {/* Dropdown for selecting cinema */}
                <div className="mt-4">
                    <label className="block text-gray-800 mb-2" htmlFor="cinema">
                        Select Cinema:
                    </label>
                    <select
                        id="cinema"
                        value={selectedCinema}
                        onChange={handleCinemaChange}
                        className="border border-gray-300 rounded-md p-2 w-full"
                    >
                        {movie?.show_timings.map((show, index) => (
                            <option key={index} value={show.cinema}>
                                {show.cinema} ({show.location})
                            </option>
                        ))}
                    </select>
                </div>

                {/* Display loading or error messages */}
                {loading && <p className="text-blue-600">Booking in progress...</p>}
                {error && <p className="text-red-600">{error}</p>}

                <button 
                    onClick={handleBooking} 
                    className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                    disabled={loading}
                >
                    🛒 Book Now
                </button>
            </div>
        </div>
    );
};

export default BookingModal;

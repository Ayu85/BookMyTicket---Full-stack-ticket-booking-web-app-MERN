// MovieCard.js
import React from 'react';
import { FaFilm, FaClock, FaMapMarkerAlt } from 'react-icons/fa';

const MovieCard = ({ movie }) => {
    return (
        <div className="bg-white border cursor-pointer border-gray-300 rounded-lg shadow-lg overflow-hidden transition-transform transform hover:scale-105 hover:shadow-xl p-6 w-96 flex flex-col">
            <img 
                src={movie.poster_path || 'https://play-lh.googleusercontent.com/ITkVEYAeprLzJwZxALwL0Ypuu6FWQw3zT5m2ATshNkLGFkkaYQ-T3Im9GaPM6jBxmg=w526-h296-rw'} 
                alt={movie.title} 
                className="w-full h-48 object-cover rounded-lg mb-4" 
            />
            <h3 className="text-xl font-semibold text-gray-800 mb-2">{movie.title}</h3>
            <p className="text-gray-600 mb-4">Rating: {movie.rating} ({movie.total_votes} votes)</p>
            <div className="flex-1 overflow-auto">
                <h4 className="font-medium text-gray-700 flex items-center mb-2">
                    <FaFilm className="text-blue-600 mr-1" /> Show Timings:
                </h4>
                {movie.show_timings.map((show, index) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-3 mb-3 flex justify-between items-center border border-gray-200">
                        <div className="flex items-center">
                            <FaMapMarkerAlt className="text-gray-500 mr-2" />
                            <span className="font-semibold line-clamp-1">{show.cinema}</span>
                            <span className="text-gray-500 ml-1 line-clamp-1">({show.location})</span>
                        </div>
                        <div className="flex items-center">
                            <FaClock className="text-gray-500 mr-2" />
                            <span className="font-semibold text-blue-600 line-clamp-1">{show.timing}</span>
                        </div>
                    </div>
                ))}
            </div>
            <a 
                href={movie.wiki_link} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-4 inline-block text-blue-600 hover:underline"
            >
                More Info
            </a>
        </div>
    );
};

export default MovieCard;

// MovieList.js
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import MovieCard from './MovieCard';
import ShimmerUI from '../Shimmer/ShimmerCard';
import useFetchMovies from '../hooks/useFetchMovies';
import BookingModal from './BookingModal'; // Import the modal component
import { AiOutlineSearch, AiOutlineClose } from 'react-icons/ai';

const MovieList = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedMovie, setSelectedMovie] = useState(null); // State for the selected movie
    const [isModalOpen, setIsModalOpen] = useState(false); // Modal visibility state
    useFetchMovies();
    const storeMovies = useSelector(store => store.movies.value);

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const clearSearch = () => {
        setSearchQuery('');
    };

    const openModal = (movie) => {
        setSelectedMovie(movie);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setSelectedMovie(null);
    };

    const filteredMovies = storeMovies?.filter(movie =>
        movie.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className='flex flex-col items-center pt-20'>
            <div className='w-full px-5 flex justify-center md:justify-start md:items-start items-center flex-col md:px-10'>
                <div className='flex md:justify-between items-center md:items-start w-full md:flex-row flex-col pr-5'>
                    <h1 className='text-2xl inter-semibold mb-5 text-zinc-700'>Get Your Tickets Now...</h1>
                    <div className="relative w-1/2 mb-4">
                        <AiOutlineSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Search for a movie..."
                            value={searchQuery}
                            onChange={handleSearchChange}
                            className="pl-10 pr-10 p-2 border outline-none focus:bg-yellow-50 border-gray-300 rounded-md w-full"
                        />
                        {searchQuery && (
                            <AiOutlineClose
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 cursor-pointer"
                                onClick={clearSearch}
                            />
                        )}
                    </div>
                </div>
                <div className="flex items-center md:justify-start justify-center flex-wrap gap-10 mt-5">
                    {filteredMovies?.length > 0 ? (
                        filteredMovies?.map(movie => (
                            <div key={movie._id} onClick={() => openModal(movie)}> {/* Open modal on click */}
                                <MovieCard movie={movie} />
                            </div>
                        ))
                    ) : (
                        <ShimmerUI/>
                    )}
                </div>
            </div>
            <BookingModal movie={selectedMovie} isOpen={isModalOpen} onClose={closeModal} /> {/* Modal integration */}
        </div>
    );
};

export default MovieList;

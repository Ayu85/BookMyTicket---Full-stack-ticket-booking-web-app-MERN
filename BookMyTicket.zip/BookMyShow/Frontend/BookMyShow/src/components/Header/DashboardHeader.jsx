import React, { useEffect, useState } from 'react';
import { FaRegUser } from 'react-icons/fa6';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import { CiLogout } from "react-icons/ci";
import { IoTicketOutline } from "react-icons/io5";

const DashboardHeader = () => {
    const navigate = useNavigate();
    const [isModalOpen, setModalOpen] = useState(false);

    useEffect(() => {
        // Check if the user is logged in by verifying the token
        if (!Cookies.get('token')) {
            navigate('/'); // Redirect to the root route if no token is found
        }
    }, [navigate]);

    const handleLogout = () => {
        // Remove the token from cookies
        Cookies.remove('token');
        // Redirect to the login page
        navigate('/');
    };

    return (
        <div className='bg-dashheader py-5 inter flex items-center justify-between px-8'>
            <h1 
                onClick={() => navigate('/dashboard')}
                className='text-logo flex items-center cursor-pointer text-2xl inter-bold'>
                Book<span className='text-red-500'>My</span>Ticket <IoTicketOutline className='ml-1'/>
            </h1>
            <span className='flex items-center gap-4'>
                <button 
                    onClick={() => setModalOpen(true)} 
                    className='bg-[#d42a35] flex items-center gap-1 text-md active:scale-110 hover:bg-red-700 transition-all text-white px-3 py-2 rounded-md'>
                    <CiLogout />
                    Logout
                </button>
                <button 
                    onClick={() => navigate('/userprofile')} 
                    className='bg-[#57a560] flex items-center gap-1 text-md active:scale-110 hover:bg-green-700 transition-all text-white px-3 py-2 rounded-md'>
                    <FaRegUser />
                    Profile
                </button>
            </span>
            <Modal
                isOpen={isModalOpen}
                onClose={() => setModalOpen(false)}
                onConfirm={handleLogout}
            />
        </div>
    );
};

const Modal = ({ isOpen, onClose, onConfirm }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-5 w-96">
                <h2 className="text-lg font-semibold mb-4">Confirm Logout</h2>
                <p>Are you sure you want to log out?</p>
                <div className="flex justify-end mt-4">
                    <button className="mr-2 px-4 py-2 border  border-gray-300 rounded" onClick={onClose}>
                        Cancel
                    </button>
                    <button className="px-4 py-2 bg-blue-600 text-white rounded" onClick={onConfirm}>
                        Logout
                    </button>
                </div>
            </div>
        </div>
    );
};
export default DashboardHeader
import React from 'react'
import { FaRegUser } from "react-icons/fa6";

const OfferHeader = () => {
    return (
        <div className='bg-header text-white inter-medium py-2 flex gap-2 items-center justify-center text-xl'>
            {/* <span className='bg-white text-header rounded-full px-5 '>Offer </span> */}
            🎉 Special Offer: 20% off on all movie tickets! 🎉        </div>
    )
}

export default OfferHeader
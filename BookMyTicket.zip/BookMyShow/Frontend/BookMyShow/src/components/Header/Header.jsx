import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
  return (
    <div className='fixed py-6 px-8 flex items-center justify-between   text-white w-screen' >
      <h1 className='inter-semibold text-xl'>BookMyTicket</h1>
      <div className='text-[13px] inter-medium flex items-center gap-8'>
        <Link to={'/login'}>
          <button className='border px-6  py-1 hover:bg-white hover:bg-opacity-30 transition-all'>Login</button>
        </Link>
        <Link to={'/signup'}>
          <button className='border px-6  py-1  hover:bg-white hover:bg-opacity-30 transition-all'>Signup</button>
        </Link>
      </div>
    </div>
  )
}

export default Header
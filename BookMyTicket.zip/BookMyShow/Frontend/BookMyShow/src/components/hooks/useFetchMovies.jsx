// useFetchMovies.js
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { addMovies } from '../../redux/movieSlice';
import Cookies from 'js-cookie';

const useFetchMovies = () => {
    const dispatch = useDispatch();

    useEffect(() => {
        const fetchMovies = async () => {
            try {
                // Check for the token in cookies
                const token = Cookies.get('token');
                if (token) {
                    const response = await axios.get('http://localhost:8000/movie/getAllMovies', {
                        headers: {
                            Authorization: `Bearer ${token}`, // Optional: include token in headers
                        }
                    });
                    dispatch(addMovies(response.data));
                    console.log(response.data);
                }
            } catch (error) {
                console.error("Error fetching movies:", error);
            }
        };

        fetchMovies();
    }, [dispatch]);
};

export default useFetchMovies;

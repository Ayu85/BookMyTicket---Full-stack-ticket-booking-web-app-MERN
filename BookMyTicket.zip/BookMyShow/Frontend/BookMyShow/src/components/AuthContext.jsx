import React, { createContext, useState, useEffect } from 'react';
import Cookies from 'js-cookie';

// Create the Auth Context
export const AuthContext = createContext();

// Auth Provider Component
export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Retrieve the token from cookies when the component mounts
    const cookieToken = Cookies.get('token');
    if (cookieToken) {
      setToken(cookieToken);
      // You can decode the token to get user information if needed
      // For example, using jwt-decode library
      // const decoded = jwt_decode(cookieToken);
      // setUser(decoded);
    }
  }, []);

  const login = () => {
    const cookieToken = Cookies.get('token');
    if (cookieToken) {
      setToken(cookieToken);
      // Optionally decode the token to get user info
      // const decoded = jwt_decode(cookieToken);
      // setUser(decoded);
    }
  };

  const logout = () => {
    Cookies.remove('token'); // Remove the token cookie
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

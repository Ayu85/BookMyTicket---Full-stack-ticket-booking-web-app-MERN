// Shimmer.js
import React from 'react';

const Shimmer = () => {
    return (
        <div className="bg-white border border-gray-300 rounded-lg shadow-lg p-6 w-96 animate-pulse">
            <div className="bg-gray-200 h-48 rounded-lg mb-4" />
            <div className="h-6 bg-gray-300 rounded mb-2" />
            <div className="h-4 bg-gray-300 rounded mb-4 w-3/4" />
            <div className="h-4 bg-gray-200 rounded mb-2" />
            <div className="h-4 bg-gray-200 rounded mb-2" />
            <div className="h-4 bg-gray-300 rounded mb-2" />
        </div>
    );
};

const ShimmerUI = () => {
    return (
        <div className="flex items-center justify-center flex-wrap gap-10 px-20 pt-20">
            {Array.from({ length: 20 }).map((_, index) => (
                <Shimmer key={index} />
            ))}
        </div>
    );
};

export default ShimmerUI;

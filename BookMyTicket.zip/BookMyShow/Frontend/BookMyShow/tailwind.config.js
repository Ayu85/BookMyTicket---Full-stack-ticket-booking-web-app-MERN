/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",],
  theme: {
    extend: {
      colors:{
        'header':"#4EA8B9",
        'dashheader':"#EDEEF1",
        'logo':"#000031"
      }
    },
  },
  plugins: [],
}


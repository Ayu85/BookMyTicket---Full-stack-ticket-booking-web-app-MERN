import express from "express";
import dotenv from 'dotenv';
import colors from 'colors'
import logger from "./utils/logger.js";
import morgan from "morgan";
import connectDatabse from "./database/db.js";
import { userRoutes } from "./routes/user.routes.js";
import cookieParser from "cookie-parser";
import cors from 'cors'
import { movieRoutes } from "./routes/movie.route.js";
dotenv.config()
connectDatabse()
const server = express()
const morganFormat = ":method :url :status :response-time ms";
server.use(
    morgan(morganFormat, {
        stream: {
            write: (message) => {
                const logObject = {
                    method: message.split(" ")[0],
                    url: message.split(" ")[1],
                    status: message.split(" ")[2],
                    responseTime: message.split(" ")[3],
                };
                logger.info(JSON.stringify(logObject));
            },
        },
    })
);
server.use(cors({
  origin: 'http://localhost:7777', // Your frontend URL
  credentials: true // Enable set cookies
}));
server.use(express.json())
server.use(cookieParser())
server.use('/user',userRoutes)
server.use('/movie',movieRoutes)
server.listen(process.env.PORT, console.log(`App running on port ${process.env.PORT}`.bgMagenta))
import mongoose from "mongoose"
import { DB_NAME } from "../utils/constants.js"

const connectDatabse = async () => {
    try {
        const connection = await mongoose.connect(`${process.env.MONGO_URI}/${DB_NAME}`)
        console.log(`🟩 Database connected 🟩 DB_NAME:- ${connection.connection.name}`.bgGreen);

    } catch (error) {
        console.log(`🟥 Database connection failed 🟥`.bgRed);

    }
}
export default connectDatabse
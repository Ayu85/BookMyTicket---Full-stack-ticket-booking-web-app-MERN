import userModel from "../models/user.model.js"
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
export const signUpUser = async (req, res) => {
    try {
        const { name, email, password, contact } = req.body
        if (!name || !email || !password || !contact)
            return res.status(406).send({ msg: "Missing fields", success: false })

        const doesUserExists = await userModel.findOne({ email })
        if (doesUserExists)
            return res.status(406).send({ msg: "User with email already exists", success: false })
        const hashedPassword = await bcrypt.hash(password, 5)
        const user = await userModel.create({ name, email, password: hashedPassword, contact })
        if (user)
            return res.status(202).send({ msg: "User created successfully", success: true, user: { name: user.name, email: user.email, contact: user.contact } })
        return res.status(502).send({ msg: "User signup failed,please try again", success: false })

    } catch (error) {
        return res.status(502).send({ msg: "User signup failed,please try again", success: false })

    }
}
export const loginUser = async (req, res) => {
    try {

        const { email, password } = req.body;
        const user = await userModel.findOne({ email })
        console.log(user);
        if (!user)
            return res.status(406).send({ msg: "User not found", success: false })
        const token = await jwt.sign({ id: user._id }, process.env.JWT_SECRET)

        if (await user.matchPassword(password)) {
            res.cookie('token', token, {
                // httpOnly: true, // Comment this out for testing
                // secure: false, // Comment this out for testing
                sameSite: 'Lax', // Change for testing
                maxAge: 3600000
            });

            return res.status(202).send({ msg: "logged in successfully", success: true, user: { name: user.name, email: user.email } })
        }
        return res.status(402).send({ msg: "Invalid password", success: false })

    } catch (error) {
        return res.status(502).send({ msg: "User signup failed,please try again", success: false })

    }
}
export const getUserProfile = async (req, res) => {
    try {
        const token = req.cookies.token
        console.log(token);
        const decoded = await jwt.verify(token, process.env.JWT_SECRET)
        const user = await userModel.findOne({ _id: decoded.id })
        if (user)
            return res.status(200).send({ name: user.name, email: user.email, contact: user.contact, bookings: user.bookings, address: user.address })
        return res.status(502).send({ msg: "Something went wrong", success: false })

    } catch (error) {
        return res.status(502).send({ msg: "Something went wrong", success: false })

    }
}
export const changePassword = async (req, res) => {
    try {
        const { email, currentPassword, newPassword } = req.body;
        // console.log(email,currentPassword,newPassword);
        const user = await userModel.findOne({ email })
        if (user && await user.matchPassword(currentPassword)) {
            console.log("log");
            const newHash = await bcrypt.hash(newPassword, 5)
            const user = await userModel.findOneAndUpdate({ email }, {
                password: newHash
            })
            return res.status(200).send({ msg: "Password changed successfully", success: true })
        }
        return res.status(200).send({ msg: "Wrong password entered", success: false })

    } catch (error) {
        return res.status(502).send({ msg: "Something went wrong", success: false })

    }
}
export const updateAddress = async (req, res) => {
    try {
        const { email, address } = req.body;

        const user = await userModel.findOne({ email })
        console.log(address);
        if (user) {
            await userModel.updateOne({ email }, {
                address: address
            })
            return res.status(200).send({ msg: "Address updated successfully", success: true })

        }
        return res.status(200).send({ msg: "User not found", success: false })

    } catch (error) {
        return res.status(502).send({ msg: "Something went wrong", success: false })

    }
}
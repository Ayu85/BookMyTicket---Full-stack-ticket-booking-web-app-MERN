import jwt from "jsonwebtoken"
import Movie from "../models/movie.model.js"
import userModel from "../models/user.model.js"
import BookingModel from "../models/Booking.model.js"

export const getAllMovies = async (req, res) => {
    try {
        const movies = await Movie.find()
        return res.status(200).send(movies)
    } catch (error) {
        return res.status(502).send({ msg: "something went wrong" })
    }
}
export const bookTicket = async (req, res) => {
    try {
        const token = req.cookies.token
        const decoded = await jwt.verify(token, process.env.JWT_SECRET)
        const user = await userModel.findOne({ _id: decoded.id })
        const { moviename, totalAmount, totalSeats, theatreName } = req.body;
        // Validate the input
        if (!moviename || !totalAmount || !totalSeats || !theatreName) {
            return res.status(400).json({ message: 'All fields are required.' });
        }
        const booking = await BookingModel.create({ user: user._id, moviename, totalAmount, totalSeats, theatreName })
        await userModel.updateOne({ _id: user._id }, {
            $push: { bookings: booking._id }
        })
        return res.status(200).send({ msg: "Ticket booked", booking })
    } catch (error) {
        return res.status(502).send({ msg: "something went wrong" })

    }
}
import mongoose from "mongoose";


// Main movie schema
const movieSchema = new mongoose.Schema({
    _id: { type: String, required: true },
    title: { type: String, required: true },
    imdb_id: { type: String, required: true },
    poster_path: { type: String, required: true },
    wiki_link: { type: String, required: true },
    rating: { type: Number, required: true },
    total_votes: { type: Number, required: true },
    show_timings: [{
        cinema: { type: String, required: true },
        location: { type: String, required: true },
        timing: { type: String, required: true }
    }] // Array of show timings
});

// Create the Movie model
const Movie = mongoose.model('Movie', movieSchema);
export default Movie

import mongoose from "mongoose";
import bcrypt from 'bcrypt'
const UserSchema = mongoose.Schema({
    name: {
        type: String, required: true
    },
    email: {
        type: String, required: true
    },
    contact: {
        type: String, required: true
    },
    bookings: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking'
    }],
    password: {
        type: String,
        required: true
    }, 
    address: {
        type: String,
        default: "None"
    }
}, { timestamps: true })

UserSchema.methods.matchPassword = async function (enteredPassword) {
    console.log("password check method");

    return await bcrypt.compare(enteredPassword, this.password)

}
export default mongoose.model('User', UserSchema);

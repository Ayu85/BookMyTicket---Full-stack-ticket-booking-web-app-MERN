import mongoose from "mongoose";

const BookingSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true // Assuming every booking must have a user
    },
    moviename: {
        type: String,
    },
    totalAmount: {
        type: Number, // Changed to Number for calculations
        required: true
    },
    totalSeats: {
        type:Number
    },
    theatreName:{
        type:String
    }
}, { timestamps: true });

export default mongoose.model('Booking', BookingSchema);

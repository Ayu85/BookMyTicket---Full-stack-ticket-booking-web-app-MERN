import { Router } from "express";
import { changePassword, getUserProfile, loginUser, signUpUser, updateAddress } from "../controllers/user.js";

const router = Router()
router.post('/signUpUser',signUpUser)
router.post('/loginUser',loginUser)
router.get('/getUserProfile',getUserProfile)
router.post('/changePassword',changePassword)
router.post('/updateAddress',updateAddress)
export const userRoutes = router
import { Router } from "express";
import { bookTicket, getAllMovies } from "../controllers/movie.js";

const router = Router()
router.get('/getAllMovies', getAllMovies)
router.post('/bookticket', bookTicket)
export const movieRoutes = router